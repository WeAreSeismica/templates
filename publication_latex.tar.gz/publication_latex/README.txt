Functional: Intuitive Functional Programming Interface for LaTeX2
Copyright : 2022 (c) Jianrui Lyu <tolvjr@163.com>
CTAN Page : https://ctan.org/pkg/functional
Repository: https://github.com/lvjr/functional
Repository: https://bitbucket.org/lvjr/functional
License   : The LaTeX Project Public License 1.3c
